## Local Secret Notes

This file is local-only and ignored by git.

### Source
- DB URL copied on 2026-04-16 from `G:\다른 컴퓨터\내 컴퓨터\133-relovetree\.env`
- Test account defaults verified on 2026-04-16 from `G:\다른 컴퓨터\내 컴퓨터\133-relovetree\scripts\create-test-accounts.js`

### Test Accounts
- Admin: `admin.test@lovetree.dev` / `LoveTree!admin2025`
- User: `user.test@lovetree.dev` / `LoveTree!user2025`

### Local Files
- Active DB env: `.env`
- Test account JSON: `.local/test-accounts.json`

### Vercel Integration
- **VERCEL_PROJECT_TOKEN**: `vcp_1XIW9uBiZEIaTB9z2H5UnKDYVhLDik9BMCBiMlIt4A4WZieiTh1dsvre` (Added on 2026-04-22 per user request)
